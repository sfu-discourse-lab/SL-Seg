'''
Copyright 2009 Milan Tofiloski, Julian Brooke
This file is part of SLSeg.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SLSeg.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys

'''
usage: python insert_paragraph_breaks_for_breakSent.py infile outfile
'''

args = sys.argv

finput = open(args[1], "r")
foutput = open(args[2], "w")

paragraphs = finput.read()

#add spaces after "(" so that breaksent doesn't break on periods in "(i.e." or "(e.g."
paragraphs = paragraphs.replace("(", "( ")

list_of_paragraphs = paragraphs.split("\n")

for p in list_of_paragraphs:
	p = p.strip()
	if p != "":
		tagged_paragraphs = "<PARAGRAPH>\n" + p + "\n"
		foutput.write(tagged_paragraphs)

finput.close()
foutput.close()

