'''
Copyright 2009 Milan Tofiloski, Julian Brooke
This file is part of SLSeg.

    Foobar is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with SLSeg.  If not, see <http://www.gnu.org/licenses/>.
'''

import sys
swap_word = {"aren't": "are not", "can't": "can not", "couldn't": "could not", "didn't": "did not", "doesn't": "does not", "don't": "do not", "hadn't": "had not", "hasn't": "has not", "haven't": "have not", "isn't": "is not", "mightn't": "might not", "mustn't": "must not", "oughtn't": "ought not", "shan't": "shall not", "shouldn't": "should not", "wasn't": "was not", "weren't": "were not", "won't": "will not", "wouldn't": "would not", "arent": "are not", "cant": "can not", "couldnt": "could not", "didnt": "did not", "doesnt": "does not", "dont": "do not","hadnt": "had not", "hasnt": "has not", "havent": "have not", "isnt" :"is not", "mightnt": "might not", "mustnt": "must not", "oughtnt":"ought not", "shant": "shall not", "shouldnt": "should not", "wasnt":"was not", "werent": "were not", "wont": "will not", "wouldnt": "would not", "'cause": "because", "'cuz": "because",  "kinda":"kind of", "sorta" : "sort of", "gonna": "going to", "wanna": "want to", "vs.":"versus"}

swap_char = {"--": " - ", chr(147): '"', chr(148): '"', chr(145): "'", chr(146): "'", chr(151): " - ", chr(133): "...", chr(150):" - "}

f = open (sys.argv[1])
text = f.read()
f.close()
after_word_stuff = [" ", ".", ",", ":", ";", '"', ")", "?", "!"]

def isnotnegone(i):
    return i !=-1

for char in swap_char.keys():
    text = text.replace(char, swap_char[char])

for word in swap_word.keys():
    for stuff in after_word_stuff:
        text = text.replace(" " + word + stuff, " " + swap_word[word] + stuff)
        text = text.replace(word[0].upper() + word[1:] + stuff, swap_word[word][0].upper() + swap_word[word][1:] + stuff)

i = 0
while not (text.find(".", i) == -1 and text.find("!", i) == -1 and text.find ("?", i) == -1):
    i = min(filter(isnotnegone, [text.find(".", i), text.find("!", i), text.find("?", i)]))
    mytype = text[i]
    if i + 4 < len(text) and i - 4 >= 0 and (text[i-1].islower() or text[i-1] in [")"]) and (text[i+1].isupper() or text[i-1] in ["("]) and (mytype != "." or not (mytype in text[i-4:i] or mytype in text[i+1:i+5])):
        text = text[:i+1] + " " + text[i+1:]
    else:
        i += 1

f = open(sys.argv[2], "w")
f.write(text)
f.close()

